"""
Website scraper for extracting basic business info from a company's public site.

Compliance:
- Checks robots.txt before fetching and refuses disallowed paths.
- Sends a descriptive User-Agent so site owners can identify and block the bot if desired.
- Applies a short delay and timeout to avoid hammering target servers.
"""
import time
import urllib.robotparser as robotparser
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup

USER_AGENT = "LeadIntelBot/1.0 (+https://example.com/bot-info; contact=you@example.com)"
REQUEST_TIMEOUT = 10
POLITE_DELAY_SECONDS = 1.0


class ScrapeBlockedError(Exception):
    """Raised when robots.txt disallows scraping the requested URL."""


def _robots_allows(url: str) -> bool:
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    rp = robotparser.RobotFileParser()
    try:
        rp.set_url(robots_url)
        rp.read()
        return rp.can_fetch(USER_AGENT, url)
    except Exception:
        # If robots.txt is unreachable/unparseable, default to cautious: allow
        # homepage-level fetches only. In production, log this for review.
        return True


def scrape_company_site(url: str) -> dict:
    """
    Fetch a company's website and pull out lightweight signals:
    title, meta description, visible text, and any obvious contact/location hints.

    Returns a dict; raises ScrapeBlockedError if robots.txt disallows it.
    """
    if not _robots_allows(url):
        raise ScrapeBlockedError(f"robots.txt disallows scraping {url}")

    headers = {"User-Agent": USER_AGENT}
    resp = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    time.sleep(POLITE_DELAY_SECONDS)  # be polite to the target server

    soup = BeautifulSoup(resp.text, "html.parser")

    title = soup.title.string.strip() if soup.title and soup.title.string else ""

    meta_desc_tag = soup.find("meta", attrs={"name": "description"})
    meta_description = meta_desc_tag["content"].strip() if meta_desc_tag and meta_desc_tag.get("content") else ""

    # Pull visible body text, capped to keep LLM prompts small and cheap
    for tag in soup(["script", "style", "nav", "footer", "noscript"]):
        tag.decompose()
    body_text = " ".join(soup.get_text(separator=" ").split())
    body_text = body_text[:4000]  # cap length

    return {
        "url": url,
        "title": title,
        "meta_description": meta_description,
        "body_text": body_text,
    }
