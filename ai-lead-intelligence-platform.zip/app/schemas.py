from pydantic import BaseModel, HttpUrl
from typing import Optional
from datetime import datetime


class ScrapeRequest(BaseModel):
    url: str
    icp_description: Optional[str] = None  # ideal customer profile, used for scoring


class LeadOut(BaseModel):
    id: int
    company_name: str
    website: Optional[str] = None
    industry: Optional[str] = None
    location: Optional[str] = None
    company_size: Optional[str] = None
    ai_summary: Optional[str] = None
    fit_score: Optional[float] = None
    fit_reasoning: Optional[str] = None
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class EmailRequest(BaseModel):
    lead_id: int
    tone: Optional[str] = "professional"  # professional / casual / direct
    sender_company: Optional[str] = "Our Company"
    sender_value_prop: Optional[str] = None


class EmailOut(BaseModel):
    id: int
    lead_id: int
    subject: str
    body: str
    tone: str

    class Config:
        from_attributes = True


class StatusUpdate(BaseModel):
    status: str  # new / reviewed / contacted / rejected
