from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database import Base


class Lead(Base):
    """A scraped/enriched business lead."""
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True)
    company_name = Column(String(255), nullable=False)
    website = Column(String(500), nullable=True)
    industry = Column(String(255), nullable=True)
    location = Column(String(255), nullable=True)
    company_size = Column(String(100), nullable=True)
    description_raw = Column(Text, nullable=True)       # raw scraped text
    ai_summary = Column(Text, nullable=True)             # LLM-generated summary
    fit_score = Column(Float, nullable=True)             # 0-100 ICP fit score
    fit_reasoning = Column(Text, nullable=True)          # why the LLM scored it this way
    source_url = Column(String(500), nullable=True)
    status = Column(String(50), default="new")           # new / reviewed / contacted / rejected
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    emails = relationship("OutreachEmail", back_populates="lead", cascade="all, delete-orphan")


class OutreachEmail(Base):
    """An AI-drafted outreach email tied to a lead."""
    __tablename__ = "outreach_emails"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    subject = Column(String(500), nullable=True)
    body = Column(Text, nullable=True)
    tone = Column(String(50), default="professional")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    lead = relationship("Lead", back_populates="emails")
