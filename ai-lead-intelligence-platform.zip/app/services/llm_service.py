"""
LLM service — wraps calls to the Groq API (LLaMA 3.3 70B) for:
  1. Summarizing a scraped business into a clean company profile.
  2. Scoring the lead's fit against an Ideal Customer Profile (ICP).
  3. Drafting a personalized outreach email.

Design notes for cost-consciousness (relevant to the take-home brief):
- Summarization and scoring are combined into a single call to halve round trips.
- Uses a smaller/cheaper model for summarization+scoring, and only calls the
  (optionally larger) model for email drafting on leads that pass the score threshold.
- All prompts are capped in length upstream (scraper truncates body text).
"""
import os
import json
from groq import Groq

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
SUMMARY_MODEL = os.getenv("GROQ_SUMMARY_MODEL", "llama-3.1-8b-instant")
EMAIL_MODEL = os.getenv("GROQ_EMAIL_MODEL", "llama-3.3-70b-versatile")

_client = None


def get_client() -> Groq:
    global _client
    if _client is None:
        if not GROQ_API_KEY:
            raise RuntimeError(
                "GROQ_API_KEY is not set. Export it or add it to a .env file before running."
            )
        _client = Groq(api_key=GROQ_API_KEY)
    return _client


def summarize_and_score(company_name: str, scraped_text: str, icp_description: str | None) -> dict:
    """
    Single LLM call that returns a structured JSON with:
    industry, location, company_size (best guess), ai_summary, fit_score (0-100), fit_reasoning.
    """
    icp_clause = (
        f"The ideal customer profile (ICP) to score against is: {icp_description}"
        if icp_description
        else "No specific ICP was given — score generically on business clarity, "
             "market opportunity, and likelihood of needing B2B software/services."
    )

    system_prompt = (
        "You are a B2B sales research assistant. You read raw scraped website text "
        "and return ONLY valid JSON (no markdown, no commentary) with these exact keys: "
        '"industry", "location", "company_size", "ai_summary", "fit_score", "fit_reasoning". '
        "fit_score must be an integer 0-100. company_size should be a rough bracket like "
        "'1-10', '11-50', '51-200', '200+', or 'unknown' if not inferable. "
        "ai_summary should be 2-3 sentences in plain business language."
    )

    user_prompt = (
        f"Company name: {company_name}\n\n"
        f"{icp_clause}\n\n"
        f"Raw scraped website text:\n{scraped_text}\n\n"
        "Return the JSON object now."
    )

    client = get_client()
    completion = client.chat.completions.create(
        model=SUMMARY_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.3,
        max_tokens=500,
        response_format={"type": "json_object"},
    )

    raw = completion.choices[0].message.content
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # Fallback: return something usable rather than crashing the pipeline
        data = {
            "industry": "unknown",
            "location": "unknown",
            "company_size": "unknown",
            "ai_summary": raw[:500],
            "fit_score": 50,
            "fit_reasoning": "Model did not return valid JSON; showing raw output as summary.",
        }
    return data


def draft_outreach_email(
    company_name: str,
    ai_summary: str,
    tone: str,
    sender_company: str,
    sender_value_prop: str | None,
) -> dict:
    """Generate a personalized subject + body outreach email for a given lead."""
    tone_instructions = {
        "professional": "Formal, concise, respectful of the reader's time.",
        "casual": "Warm and conversational, still credible.",
        "direct": "Very short, gets straight to the value proposition and ask.",
    }.get(tone, "Formal, concise, respectful of the reader's time.")

    value_prop = sender_value_prop or (
        f"{sender_company} helps businesses like theirs grow through practical, "
        "AI-driven tools tailored to their industry."
    )

    system_prompt = (
        "You write short, highly personalized B2B cold outreach emails. "
        "Return ONLY valid JSON with keys 'subject' and 'body'. "
        "The body should be under 150 words, reference the recipient's specific "
        "business context, and end with a clear, low-friction call to action "
        "(e.g. a 15-minute call). Do not use generic filler like 'I hope this email finds you well.'"
    )

    user_prompt = (
        f"Recipient company: {company_name}\n"
        f"What we know about them: {ai_summary}\n"
        f"Tone: {tone_instructions}\n"
        f"Sender company: {sender_company}\n"
        f"Sender's value proposition: {value_prop}\n\n"
        "Write the email now as JSON: {\"subject\": ..., \"body\": ...}"
    )

    client = get_client()
    completion = client.chat.completions.create(
        model=EMAIL_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.6,
        max_tokens=400,
        response_format={"type": "json_object"},
    )

    raw = completion.choices[0].message.content
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        data = {"subject": f"Quick question for {company_name}", "body": raw[:800]}
    return data
