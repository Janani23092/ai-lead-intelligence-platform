from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List, Optional
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.database import get_db
from app.models.lead import Lead
from app.schemas import ScrapeRequest, LeadOut, StatusUpdate
from app.scrapers.website_scraper import scrape_company_site, ScrapeBlockedError
from app.services import llm_service

router = APIRouter(prefix="/leads", tags=["leads"])
limiter = Limiter(key_func=get_remote_address)


@router.post("/scrape", response_model=LeadOut)
@limiter.limit("10/minute")
def scrape_and_score_lead(request: Request, payload: ScrapeRequest, db: Session = Depends(get_db)):
    """
    Scrape a company website, summarize it with an LLM, score it against an
    optional ICP description, and persist it as a new Lead.
    """
    try:
        scraped = scrape_company_site(payload.url)
    except ScrapeBlockedError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to scrape URL: {e}")

    company_name = scraped["title"] or payload.url

    try:
        enriched = llm_service.summarize_and_score(
            company_name=company_name,
            scraped_text=scraped["body_text"] or scraped["meta_description"],
            icp_description=payload.icp_description,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"LLM enrichment failed: {e}")

    lead = Lead(
        company_name=company_name,
        website=payload.url,
        industry=enriched.get("industry"),
        location=enriched.get("location"),
        company_size=enriched.get("company_size"),
        description_raw=scraped["body_text"],
        ai_summary=enriched.get("ai_summary"),
        fit_score=float(enriched.get("fit_score", 0)),
        fit_reasoning=enriched.get("fit_reasoning"),
        source_url=payload.url,
        status="new",
    )
    db.add(lead)
    db.commit()
    db.refresh(lead)
    return lead


@router.get("", response_model=List[LeadOut])
def list_leads(
    min_score: Optional[float] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """List leads, optionally filtered by minimum fit score and/or status, ranked by score."""
    query = db.query(Lead)
    if min_score is not None:
        query = query.filter(Lead.fit_score >= min_score)
    if status is not None:
        query = query.filter(Lead.status == status)
    return query.order_by(desc(Lead.fit_score)).all()


@router.get("/{lead_id}", response_model=LeadOut)
def get_lead(lead_id: int, db: Session = Depends(get_db)):
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead


@router.patch("/{lead_id}/status", response_model=LeadOut)
def update_status(lead_id: int, payload: StatusUpdate, db: Session = Depends(get_db)):
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    valid = {"new", "reviewed", "contacted", "rejected"}
    if payload.status not in valid:
        raise HTTPException(status_code=400, detail=f"status must be one of {valid}")
    lead.status = payload.status
    db.commit()
    db.refresh(lead)
    return lead


@router.delete("/{lead_id}")
def delete_lead(lead_id: int, db: Session = Depends(get_db)):
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    db.delete(lead)
    db.commit()
    return {"deleted": lead_id}
