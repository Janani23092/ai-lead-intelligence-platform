from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.lead import Lead, OutreachEmail
from app.schemas import EmailRequest, EmailOut
from app.services import llm_service

router = APIRouter(prefix="/emails", tags=["emails"])


@router.post("/generate", response_model=EmailOut)
def generate_email(payload: EmailRequest, db: Session = Depends(get_db)):
    """Generate a personalized outreach email for a given lead and store it."""
    lead = db.query(Lead).filter(Lead.id == payload.lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    if not lead.ai_summary:
        raise HTTPException(status_code=400, detail="Lead has no AI summary yet; scrape/score it first.")

    try:
        drafted = llm_service.draft_outreach_email(
            company_name=lead.company_name,
            ai_summary=lead.ai_summary,
            tone=payload.tone or "professional",
            sender_company=payload.sender_company or "Our Company",
            sender_value_prop=payload.sender_value_prop,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"LLM email generation failed: {e}")

    email = OutreachEmail(
        lead_id=lead.id,
        subject=drafted.get("subject", f"Quick note for {lead.company_name}"),
        body=drafted.get("body", ""),
        tone=payload.tone or "professional",
    )
    db.add(email)
    db.commit()
    db.refresh(email)
    return email


@router.get("/lead/{lead_id}", response_model=List[EmailOut])
def list_emails_for_lead(lead_id: int, db: Session = Depends(get_db)):
    return db.query(OutreachEmail).filter(OutreachEmail.lead_id == lead_id).all()
