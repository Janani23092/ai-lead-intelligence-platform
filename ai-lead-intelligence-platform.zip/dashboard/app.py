"""
Streamlit dashboard for the AI Sales & Lead Intelligence Platform.

Run with:
    streamlit run dashboard/app.py

Talks to the FastAPI backend over HTTP (set API_BASE_URL env var if not localhost).
"""
import os
import streamlit as st
import requests
import pandas as pd

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="AI Lead Intelligence", page_icon="🎯", layout="wide")

st.title("🎯 AI Sales & Lead Intelligence Platform")
st.caption("Scrape → Summarize → Score → Outreach, powered by LLaMA 3.3 via Groq")

tab_scrape, tab_leads, tab_outreach = st.tabs(["➕ Add Lead", "📊 Leads Dashboard", "✉️ Outreach"])

# ---------------------------------------------------------------------------
# TAB 1: Add a lead via scraping
# ---------------------------------------------------------------------------
with tab_scrape:
    st.subheader("Scrape & Score a New Lead")
    with st.form("scrape_form"):
        url = st.text_input("Company website URL", placeholder="https://example-business.com")
        icp = st.text_area(
            "Ideal Customer Profile (optional)",
            placeholder="e.g. Small-to-mid size manufacturing companies in India, 10-200 employees, "
                        "no existing e-commerce presence, likely to need B2B digital tools.",
            height=100,
        )
        submitted = st.form_submit_button("Scrape & Score", type="primary")

    if submitted:
        if not url:
            st.error("Please enter a URL.")
        else:
            with st.spinner("Scraping site and running LLM analysis..."):
                try:
                    resp = requests.post(
                        f"{API_BASE_URL}/leads/scrape",
                        json={"url": url, "icp_description": icp or None},
                        timeout=60,
                    )
                    if resp.status_code == 200:
                        lead = resp.json()
                        st.success(f"Added: {lead['company_name']} — Fit score: {lead['fit_score']}")
                        st.json(lead)
                    elif resp.status_code == 403:
                        st.warning("This site's robots.txt disallows scraping. Skipped out of respect for their policy.")
                    else:
                        st.error(f"Error {resp.status_code}: {resp.json().get('detail')}")
                except requests.exceptions.ConnectionError:
                    st.error(f"Can't reach the API at {API_BASE_URL}. Is the FastAPI server running?")
                except Exception as e:
                    st.error(f"Unexpected error: {e}")

# ---------------------------------------------------------------------------
# TAB 2: Leads dashboard
# ---------------------------------------------------------------------------
with tab_leads:
    st.subheader("All Leads, Ranked by Fit Score")

    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        min_score = st.slider("Minimum fit score", 0, 100, 0)
    with col2:
        status_filter = st.selectbox("Status", ["all", "new", "reviewed", "contacted", "rejected"])
    with col3:
        if st.button("🔄 Refresh"):
            st.rerun()

    params = {"min_score": min_score}
    if status_filter != "all":
        params["status"] = status_filter

    try:
        resp = requests.get(f"{API_BASE_URL}/leads", params=params, timeout=30)
        leads = resp.json() if resp.status_code == 200 else []
    except requests.exceptions.ConnectionError:
        st.error(f"Can't reach the API at {API_BASE_URL}. Is the FastAPI server running?")
        leads = []

    if leads:
        df = pd.DataFrame(leads)
        display_cols = ["id", "company_name", "industry", "location", "company_size", "fit_score", "status"]
        display_cols = [c for c in display_cols if c in df.columns]
        st.dataframe(df[display_cols], use_container_width=True, hide_index=True)

        st.divider()
        st.subheader("Lead Detail")
        lead_ids = [l["id"] for l in leads]
        selected_id = st.selectbox("Select a lead to view details", lead_ids, format_func=lambda i: f"#{i} — {next(l['company_name'] for l in leads if l['id']==i)}")
        selected = next(l for l in leads if l["id"] == selected_id)

        c1, c2 = st.columns(2)
        with c1:
            st.markdown(f"**{selected['company_name']}**")
            st.write(f"🌐 {selected.get('website', '—')}")
            st.write(f"🏭 Industry: {selected.get('industry', '—')}")
            st.write(f"📍 Location: {selected.get('location', '—')}")
            st.write(f"👥 Size: {selected.get('company_size', '—')}")
            st.metric("Fit Score", f"{selected.get('fit_score', 0):.0f}/100")
        with c2:
            st.markdown("**AI Summary**")
            st.info(selected.get("ai_summary", "—"))
            st.markdown("**Why this score**")
            st.caption(selected.get("fit_reasoning", "—"))

        new_status = st.selectbox(
            "Update status", ["new", "reviewed", "contacted", "rejected"],
            index=["new", "reviewed", "contacted", "rejected"].index(selected["status"]),
            key=f"status_{selected_id}",
        )
        if st.button("Save status"):
            requests.patch(f"{API_BASE_URL}/leads/{selected_id}/status", json={"status": new_status})
            st.success("Updated.")
            st.rerun()
    else:
        st.info("No leads yet — add one in the '➕ Add Lead' tab.")

# ---------------------------------------------------------------------------
# TAB 3: Outreach email generation
# ---------------------------------------------------------------------------
with tab_outreach:
    st.subheader("Generate Personalized Outreach")

    try:
        resp = requests.get(f"{API_BASE_URL}/leads", timeout=30)
        leads = resp.json() if resp.status_code == 200 else []
    except requests.exceptions.ConnectionError:
        leads = []
        st.error(f"Can't reach the API at {API_BASE_URL}.")

    if leads:
        lead_id = st.selectbox(
            "Choose a lead", [l["id"] for l in leads],
            format_func=lambda i: f"#{i} — {next(l['company_name'] for l in leads if l['id']==i)} (score: {next(l['fit_score'] for l in leads if l['id']==i):.0f})",
        )
        tone = st.radio("Tone", ["professional", "casual", "direct"], horizontal=True)
        sender_company = st.text_input("Your company name", value="Pepagora")
        value_prop = st.text_area(
            "Your value proposition (optional — improves personalization)",
            placeholder="We help SMEs connect with global buyers through an AI-powered B2B marketplace.",
        )

        if st.button("✉️ Generate Email", type="primary"):
            with st.spinner("Drafting email..."):
                try:
                    r = requests.post(
                        f"{API_BASE_URL}/emails/generate",
                        json={
                            "lead_id": lead_id,
                            "tone": tone,
                            "sender_company": sender_company,
                            "sender_value_prop": value_prop or None,
                        },
                        timeout=60,
                    )
                    if r.status_code == 200:
                        email = r.json()
                        st.success("Draft ready:")
                        st.text_input("Subject", value=email["subject"])
                        st.text_area("Body", value=email["body"], height=250)
                    else:
                        st.error(f"Error {r.status_code}: {r.json().get('detail')}")
                except Exception as e:
                    st.error(f"Unexpected error: {e}")

        st.divider()
        st.subheader("Previously Generated Emails")
        try:
            hist = requests.get(f"{API_BASE_URL}/emails/lead/{lead_id}", timeout=30).json()
            for e in hist:
                with st.expander(f"{e['subject']} ({e['tone']})"):
                    st.write(e["body"])
        except Exception:
            pass
    else:
        st.info("No leads yet — add one in the '➕ Add Lead' tab first.")
